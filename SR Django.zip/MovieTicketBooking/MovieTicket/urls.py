from django.contrib import admin
from django.urls import path,include
from core import views
from django.conf.urls import url
from django.contrib.auth import views as auth_views
urlpatterns = [
    path('',views.index,name='index'),
    path('register/',views.RegisterForm,name='register'),
    path('admin/', admin.site.urls),
    path('login/',views.login,name='Login'),
    path('profile/',views.profile,name='profile'),
    path('logout/',views.logout,name='logout'),
    url(r'^(?P<movie_id>[0-9]+)/$',views.detail,name='detail'),
    url(r'^(?P<movie_id>[0-9]+)/book/$',views.book,name='book'),
    path('search/',views.search,name='search'),
    url(r'^(?P<movie_id>[0-9]+)/pay/$',views.pay,name='pay'),
    url(r'^(?P<movie_id>[0-9]+)/confirm/$',views.confirm,name='confirm'),
    path('accounts/',include('django.contrib.auth.urls')),
]
