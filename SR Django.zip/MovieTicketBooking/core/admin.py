from django.contrib import admin
from core.models import Users1,Movies,Seat,History,Date,Ticket
# Register your models here.

admin.site.register(Users1)
admin.site.register(Movies)
admin.site.register(Seat)
admin.site.register(History)
admin.site.register(Date)
admin.site.register(Ticket) 