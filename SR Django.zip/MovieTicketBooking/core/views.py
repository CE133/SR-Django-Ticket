from django.shortcuts import render,get_object_or_404
from django.http import HttpResponse


from core.models import Movies,Seat,History,Date,Ticket
from core.models import Users1
from difflib import SequenceMatcher
import operator
from django.http.response import HttpResponseRedirect
from django.views.decorators.csrf import csrf_protect
from django.views.decorators.csrf import csrf_exempt
import re
from django.http import Http404
from django.shortcuts import render_to_response
from django.views.generic import TemplateView
from django.http import HttpResponseRedirect
from django.contrib import auth
from django.template.context_processors import csrf
# Create your views here.

def index(request):
    if 'user' not in request.session:
        log=False
    else:
        log=True
    all_movies=Movies.objects.all()
    return render(request,'core/index.html',{'all_movies':all_movies,'log':log})

def RegisterForm(request):
    if request.method == 'POST':
        db=Users1()
        user=request.POST.get('user')
        password=request.POST.get('pass')
        pattern = "^.*(?=.{8,})(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=]).*$"
        result = re.findall(pattern, password)
        if (result):
            db.username=user
            db.password=request.POST.get('pass')
            db.emailid=request.POST.get('email')
            db.country=request.POST.get('country')
            db.favmovgenre=request.POST.get('genre')
            db.save()
            all_movies=Movies.objects.all()
            request.session['user'] = user
            return render(request,'core/index.html',{'all_movies':all_movies,"log":True,"user":user})
        else:
            return render(request,'core/register.html',{'error':True})
    return render(request,'core/register.html')

def login(request):
    if request.method=="GET":
        user=request.GET.get('user')
        password=request.GET.get('pass')
        if (Users1.objects.filter(username=str(user)) and Users1.objects.filter(password=str(password))):
            request.session['user'] = user
            all_movies=Movies.objects.all()
            return render(request,'core/index.html',{'all_movies':all_movies,"log":True,"user":user})
        else:
            return render(request,'core/Login.html',{"log":False,"user":''})

    return render(request,'core/Login.html',{"log":False,"user":''})
        
def logout(request):
    del request.session['user']
    print("logged Out")
    all_movies=Movies.objects.all()
    return render(request,'core/index.html',{'all_movies':all_movies,'log':False})

def detail(request,movie_id):
    user=''
    if 'user' not in request.session:
        log=False
        user=''
    else:
        log=True
        user=request.session['user']

    movie = get_object_or_404(Movies,pk=movie_id)
    return render(request,'core/detail.html',{'movie' : movie,"user":user,"log":log})

def book(request,movie_id):
    user=''
    if 'user' not in request.session:
        log=False
        user=''
    else:
        log=True
        user=request.session['user']
    movie = get_object_or_404(Movies,pk=movie_id)
    l=[]
    rs=[]
    s="["
    le=0
    l = list(Seat.objects.filter(movie=movie))
    for i in l:
        if i.isReserved==True:
            #s=s+"'"+str(i.row)+"_"+str(i.col)+"',"
            rs.append(str(i.row)+"_"+str(i.col))
            # print(i.seat_id)       
            le=le+1 
    # s=s+"]"
    # print(rs)
    # print(le)  
    sdate=request.GET.get('selected_date')
    return render(request,'core/book.html',{'movie' : movie,"ReservedSeats":l,"len":le,"sdate":sdate,"user":user,"log":log})    

def search(request):
    user=''
    if 'user' not in request.session:
        log=False
        user=''
    else:
        log=True
        user=request.session['user']
    movielist={}
    final=[]
    remains1=[]
    remains2=[]
    if request.method == 'POST':
    
        search=request.POST.get('q')
        all=Movies.objects.all()

        for i in range(0,len(all)):
            print(search,all[i].movie_title)
            m = int(SequenceMatcher(None,str(search).lower(),str(all[i].movie_title).lower()).ratio()*100)
            movielist[m]=all[i]

        sorted_d = sorted(movielist.items(), key=operator.itemgetter(0),reverse=True)
        for i in range(0,len(movielist)):
            if sorted_d[i][0]>50:
                final.append(sorted_d[i][1])
            elif sorted_d[i][0]>25 and sorted_d[i][0]<50:
                if sorted_d[i][1].movie_title[0].lower()==search[0].lower():
                    remains1.append(sorted_d[i][1])
            else:
                if sorted_d[i][1].movie_title[0].lower()==search[0].lower():
                    remains2.append(sorted_d[i][1])
        print(final,remains1,remains2)
        if len(final)==0 and len(remains1)!=0:
            print(remains1,"1")
            return render(request,'core/search.html',{'final' : remains1,"user":user,"log":lser,"length":len(remains1)})
        if len(remains1)==0 and len(remains2)!=0:
            print(remains2,"2")
            return render(request,'core/search.html',{'final' : remains2,"user":user,"log":log,"length":len(remains2)})
        print(final,"f")
        return render(request,'core/search.html',{'final' : final,"user":user,"log":log,"length":len(final)})
    return render(request,'core/search.html',{'final' : final,"user":user,"log":log})  

def pay(request,movie_id):
    user=''
    if 'user' not in request.session:
        log=False
        user=''
    else:
        log=True
        user=request.session['user']
    movie = get_object_or_404(Movies,pk=movie_id)
    seats=request.GET.get('seats')
    total=request.GET.get('total')
    sdate=request.GET.get('sdate')
    return render(request,'core/pay.html',{'seats' : seats,"total":total, 'movie':movie , 'sdate':sdate,"user":user,"log":log})
       
def confirm(request,movie_id):
    user=''
    if 'user' not in request.session:
        log=False
        user=''
    else:
        log=True
        user=request.session['user']
    movie = get_object_or_404(Movies,pk=movie_id)
    if request.method == 'POST':
        seats=request.POST.get('seats')
        total=request.POST.get('total')
        sdate=request.POST.get('sdate')
        l=[int(s) for s in re.findall(r'\d+', seats)]
        f=True
        r=0
        c=0
        count=0
        for i in l:
            if f:
                r=i
                f=False
                count=count+1
            else:
                c=i
                f=True
                count=count+1
            if count==2:
                count=0
                print(r)
                print(c)
                obj=Seat(movie=movie,row=r,col=c,isReserved=True)
                obj.save()
        # print(seats)
        unm=request.POST.get('unm')
        card=request.POST.get('CardNumber')
        cvv=request.POST.get('cvv')
        ob=History(username=unm,cardnumber=card,cvv=cvv)
        ob.save()

        o=Ticket(username=user,movie_title=movie.movie_title,showdate=sdate,showtime=movie.showtime,screen=movie.id,total=total)
        o.save()
        #print(seats)
        return render(request,'core/confirm.html',{'seats' : seats,"total":total, 'movie':movie, 'sdate':sdate,"user":user,"log":log})
    return render(request,'core/confirm.html',{'movie':movie}) 


def profile(request):
    user=''
    if 'user' not in request.session:
        log=False
        user=''
    else:
        log=True
        user=request.session['user']
    try:
        t=Ticket.objects.filter(username=user)
    except Ticket.DoesNotExist:
        t=None    
    return render(request,'core/profile.html',{"ticket":t,"log":log,"user":user}) 