from django.db import models

# Create your models here.
class Ticket(models.Model):
    username=models.CharField(max_length=50)
    movie_title=models.CharField(max_length=50)
    showdate=models.DateField(auto_now=False, auto_now_add=False)
    showtime=models.CharField(max_length=200,null=True)
    screen=models.IntegerField(null=True)
    total=models.IntegerField(null=True)

class Users1(models.Model):
    username=models.CharField(max_length=50,unique=True)
    password=models.CharField(max_length=50)
    emailid=models.EmailField(max_length=254)
    country=models.CharField(max_length=20, null=True)
    favmovgenre=models.CharField(max_length=25,null=True)
    def __str__(self):
        return self.username

class Movies(models.Model):
    movie_title=models.CharField(max_length=50,unique=True)
    price=models.IntegerField(null=True)
    genre=models.CharField(max_length=50)
    posterlink=models.URLField( max_length=500,unique=True)
    trailerlink=models.CharField( max_length=200,unique=True)
    story=models.CharField(max_length=500,unique=True)
    actors=models.CharField(max_length=300,unique=True)
    release=models.DateField(auto_now=False, auto_now_add=False)
    showdate=models.CharField(max_length=200,null=True)#ShowDate
    showtime=models.CharField(max_length=200,null=True)
    duration=models.IntegerField(null=True)
    def __str__(self):
        return self.movie_title

class Seat(models.Model):
    movie=models.ForeignKey(Movies, on_delete=models.CASCADE,null=True)
    row=models.IntegerField(null=True)
    col=models.IntegerField(null=True)
    isReserved=models.BooleanField(default=False)
    def __str__(self):
        return '%s-->%s_%s' % (self.movie, self.row, self.col)

class History(models.Model):
    username=models.CharField(max_length=100)
    cardnumber=models.IntegerField(max_length=12)
    cvv=models.IntegerField(max_length=3)
    def __str__(self):
        return self.username

class Date(models.Model):
    movie=models.ForeignKey(Movies, on_delete=models.CASCADE,null=True)
    dates=models.DateField(auto_now=False, auto_now_add=False)
  

# class Seat(models.Model):
#     total_seats=models.CharField(max_length=50,unique=True)
#     seats_booked=models.CharField(max_length=50,unique=True)
#     seats_available=models.CharField(max_length=50,unique=True)

# class Tickets(models.Model):
#     movie_title=models.CharField(max_length=50,unique=True)
#     total_tickets_bought=models.IntegerField()
#     total_price=models.IntegerField()
#     seats_allocated=models.IntegerField()


    
# class Reservation(models.Model):
#    # screening=models.ForeignKey(Screening, on_delete=models.CASCADE)
#     seat=models.ForeignKey(Seat, on_delete=models.CASCADE)
#     paid=models.BooleanField(default=False)
# #    employee_paid_id
# #    employee_reserved_id